export async function importSocialsLinks(targetSelector) {
  try {
    const res = await fetch("/html/components/social-links.html");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const html = await res.text();
    const container = document.querySelector(targetSelector);
    if (container) container.innerHTML = html;
  } catch (error) {
    console.error("Error importing social links:", error);
  }
}
