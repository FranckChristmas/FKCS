import { makeSpans, colorHoverEffect } from "./spans";
import { chevronAnimation, animateButtonText } from "./chevronButton";
import { activateLinkOnScroll } from "./navActive";
